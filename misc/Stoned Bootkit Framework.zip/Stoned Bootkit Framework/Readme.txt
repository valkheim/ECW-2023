
Stoned Bootkit Framework 1.0c

  1. Introduction
  2. Contents
  3. Changelog
  4. Contact

Peter Kleissner


1. Introduction

This framework is intended for developers. This is the public version of the package.
Please visit www.stoned-vienna.com for more information and the latest releases.
If you have any questions please write a mail to Peter@Kleissner.at. For all mails please use the subject "Stoned Bootkit Framework".

Feel free to talk and blog about Stoned, any information is improving the world and bringing it further.
All new releases are first published on the Stoned Mailing List, you can freely sign up at https://listen.jpberlin.de/mailman/listinfo/stoned.

Your PC is now Stoned! ..again


2. Contents

Following files are included in the package:

\Readme.txt
\License.txt
\Executables
\Executables\Infector.exe
\Executables\Restore.exe
\Executables\Changelog.txt
\Papers\Automatic Sinowal Extraction.pdf
\Papers\KeServiceDescriptorTable.pdf
\Papers\Paper.pdf
\Papers\Presentation.pdf
\Papers\Technical Write-Up.txt
\Papers\TrueCrypt Encryption and RawFS.txt
\Sinowal Bootkit\*  included from http://web17.webbpro.de/index.php/analysis-of-sinowal
\Boot Code\*  parts of Stoned Bootkit 1
\Infector\*
\Kon-Boot\*
\TrueCrypt Attack\Master Boot Record.bin
\TrueCrypt Attack\Re  AW  AW  Stoned Bootkit attacking TrueCrypt's full volume encryption.msg
\TrueCrypt Attack\TrueCrypt Attack.asm
\TrueCrypt Attack\TrueCrypt Foundation.lnk
\Original Stoned Virus\Stoned.asm
\Original Stoned Virus\Stoned Binary Listing.lst
\Live CD\Live CD.txt
\Live CD\Stoned LAE.iso.lnk
\Live CD\Create with 7 AIK.cmd
\Live CD\Create with Vista AIK.cmd

Please verify any executable for genuineness before executing. If you download the package other than from
www.stoned-vienna.com it is not genuine. If so, please inform Peter@Kleissner.at. If you think some files
are missing or you wish some contents to be added, please write to Peter@Kleissner.at.


3. Changelog

25.07.2009 00:40    Version 1.0   Initial release
14.08.2009 01:37    Version 1.0a  Added Hacking at Random Paper and Presentation
                                  Added document "TrueCrypt Encryption and RawFS"
                                  Removed selling notice - so many people, so many complaints, I lost my (previous) job because of that notice!
                                  Added the MBR of TrueCrypt so you can watch it with an hex editor
                                  Added Original Stoned Virus directory  with code and listing of the original stoned virus
                                  Document "Automatic Sinowal Extraction" now available in public package (don't use the TOC lol)
                                  Removed the Submissions directory
                                  Added Live CD directory containing the new Live CD and information about it
                                  Added Changelog.txt in Executables directory
13.10.2009 08:16    Version 1.0b  Added makefiles for creating the Live CD (with the Vista and 7 AIK)
                                  Added description how to create a bootable USB Flash Drive infector
                                  Added Remote Surveillance Tool documentation and testing kit
                                  Added Exe-Loader open source
14.03.2010 11:19    1.0c          New release with updated files. Removed executables, updated Live CD.txt and added modification files

Current Version: Stoned Bootkit 2 Alpha 4


4. Contact

King Kleissner :-)
Insecurity Systems InSec e.U.
Peter@Kleissner.at

Michael Eisendle

Stoned Mailing List
https://listen.jpberlin.de/mailman/listinfo/stoned

www.viennacomputerproducts.com
www.stoned-vienna.com

(C) 2010 Peter Kleissner
All rights reserved.
